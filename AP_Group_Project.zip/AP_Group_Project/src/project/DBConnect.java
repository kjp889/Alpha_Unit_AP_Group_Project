package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class DBConnect {
	private static Connection dbConn = null; 
	
	public static Connection getDatabaseConnection() {
		if (dbConn == null) {
			try {
				String url = "jdbc:mysql://localhost:3306";
				dbConn = DriverManager.getConnection(url, "root", "P@rri$889");
				
				JOptionPane.showMessageDialog(null, "Connection established",
						"Connection Status", JOptionPane.INFORMATION_MESSAGE);
			}catch(SQLException ex) {
				JOptionPane.showMessageDialog(null, "Connection Failed",
						"Connection Failed", JOptionPane.ERROR_MESSAGE);
			}catch(Exception e) {
			e.printStackTrace();
			}
		}
		return dbConn;
	}

}
