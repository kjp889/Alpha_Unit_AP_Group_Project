package project;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

public class Student implements Serializable{
	private int studId;
	private String fName;
	private String lName;
	private String[] phone = new String[3];
	private String email;
	private String password;
	
	public Student() {
		this.studId = 1804904;
		this.fName = "";
		this.lName = "";
		this.phone = new String[3];
		this.email = "";
		this.password = "";
	}
	
	public Student(int studId, String fName, String lName, String phone1, String email, String password) {
		this.studId = studId;
		this.fName = fName;
		this.lName = lName;
		this.phone[0] = phone1;
		this.email = email;
		this.password = password;
	}
	
	public Student(int studId, String fName, String lName, String phone1, String phone2, String email, String password) {
		this.studId = studId;
		this.fName = fName;
		this.lName = lName;
		this.phone[0] = phone1;
		this.phone[1] = phone2;
		this.email = email;
		this.password = password;
	}
	
	public Student(int studId, String fName, String lName, String phone1, String phone2, String phone3, String email, String password) {
		this.studId = studId;
		this.fName = fName;
		this.lName = lName;
		this.phone[0] = phone1;
		this.phone[1] = phone2;
		this.phone[2] = phone3;
		this.email = email;
		this.password = password;
	}
	
	public Student(Student student) {
		this.studId = student.studId;
		this.fName = student.fName;
		this.lName = student.lName;
		this.phone = student.phone;
		this.email = student.email;
		this.password = student.password;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public String getlName() {
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getPhone1() {
		return phone[0];
	}
	
	public String getPhone2() {
		return phone[1];
	}
	
	public String getPhone3() {
		return phone[2];
	}

	public void setPhone1(String phone) {
		this.phone[0] = phone;
	}
	
	public void setPhone2(String phone) {
		this.phone[1] = phone;
	}
	
	public void setPhone3(String phone) {
		this.phone[2] = phone;
	}
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
	@Override
	public String toString() {
		return "Student's ID#: " + studId + "\nStudent's Name: " + fName + " " + lName + "\nStudent's Phone#: " + 
				phone[0] + ", " + phone[1] + ", " + phone[2] + "\nStudent's Email: " + email + "\n";
	}
	
	public static Student getStudentInfo(int j) {
		Student stu = new Student();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT `Student`.`stud_ID`, `Student`.`fName`, `Student`.`lName`, `Student`.`email`, `phoneNum`.`phone`" 
				    +"FROM `Query_Management`.`Student` INNER JOIN `Query_Management`.`phoneNum` ON  `Student`.`stud_ID` "
				    + "= `phoneNum`.`stud_ID` WHERE `Query_Management`.`Student`.`stud_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				stu.setStudId(rs.getInt(1));
				stu.setfName(rs.getString(2));
				stu.setlName(rs.getString(3));
				stu.setEmail(rs.getString(4));
				stu.setPhone1(rs.getString(5));
				while (rs.next()) {
					stu.phone[i] = rs.getString(5);
					i++;
				}
				System.out.println(stu);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return stu;
	}
	
	public static Student getStudentInfo(String j) {
		Student stu = new Student();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT `Student`.`stud_ID`, `Student`.`fName`, `Student`.`lName`, `Student`.`email`, `phoneNum`.`phone`" 
				    +"FROM `Query_Management`.`Student` INNER JOIN `Query_Management`.`phoneNum` ON  `Student`.`stud_ID` "
				    + "= `phoneNum`.`stud_ID` WHERE `Query_Management`.`Student`.`stud_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				stu.setStudId(rs.getInt(1));
				stu.setfName(rs.getString(2));
				stu.setlName(rs.getString(3));
				stu.setEmail(rs.getString(4));
				stu.setPhone1(rs.getString(5));
				while (rs.next()) {
					stu.phone[i] = rs.getString(5);
					i++;
				}
				System.out.println(stu);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return stu;
	}
	
	public static void main(String[] args) {	
		
		Student.getStudentInfo(1804904);
	}

}

