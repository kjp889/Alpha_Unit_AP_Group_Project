package project;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JOptionPane;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import gui.AdvisorGui;
import gui.LoginGui;
import gui.StudentDashboard;
import gui.SupervisorGui;


public class Login implements Serializable{
	private static final Logger Logger = LogManager.getLogger(Login.class);
	private String userName;
	private String pwrd;
	private String type;
	
	public Login() {
		this.userName = "";
		this.pwrd = "";
		this.type = "";
	}
		
	public Login(String userName, String pwrd) {
		this.userName = userName;
		this.pwrd = pwrd;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPwrd() {
		return pwrd;
	}

	public void setPwrd(String pwrd) {
		this.pwrd = pwrd;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	
	public static void login(String username, String pwrd) {
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT `Query_Management`.`Staff`.`staff_ID`, `Query_Management`.`Staff`.`pword`, "
					+ "`Query_Management`.`Staff`.`staff_Type` FROM `Query_Management`.`Staff`  "  
					+ "WHERE `Query_Management`.`Staff`.`staff_ID`='" + username + "'AND `Query_Management`.`Staff`.`pword`='"
					+ pwrd + "' UNION SELECT `Query_Management`.`Student`.`stud_ID`, `Query_Management`.`Student`.`pword`, "
					+ "`Query_Management`.`Student`.`stud_type` FROM `Query_Management`.`Student` WHERE `Query_Management`.`Student`.`stud_ID`='"
					+ username + "' AND `Query_Management`.`Student`.`pword`='" + pwrd + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if(rs.next()) {
				String type = rs.getString(3);
				System.out.println(type);
				if (type!=null) {
					if (type.equalsIgnoreCase("Sup")) {
						JOptionPane.showMessageDialog(null,"Supervisor Login Successfully");
						Logger.info(username + "Login Successfully");
						new SupervisorGui(Supervisor.getStaffInfo(username));
						
					}else if(type.equalsIgnoreCase("Adv")) {
						JOptionPane.showMessageDialog(null,"Advisor Login Successfully");
						Logger.info(username + "Login Successfully");
						new AdvisorGui(Advisor.getStaffInfo(username));
						
					}
				}else {
					JOptionPane.showMessageDialog(null,"Student Login Successfully");
					Logger.info(username + "Login Successfully");
					new StudentDashboard(Student.getStudentInfo(username));
					
				}
			}else {
				JOptionPane.showMessageDialog(null,"Incorect username and password");
				Logger.warn(username + "Login Attempt Unsuccessfully");
				new LoginGui();
				
			}
		}catch (Exception e) {
			e.printStackTrace();
			Logger.error("Test ERROR Message"+ e);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login.login("1001", "1234");

	}

}