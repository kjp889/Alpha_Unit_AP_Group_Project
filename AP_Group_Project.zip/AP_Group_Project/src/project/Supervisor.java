package project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Supervisor {
	private String type;
	private int id;
	private String fname;
	private String lname;
	private String pword;
	
		
	public Supervisor() {
		this.id = 0;
		this.fname = "";
		this.lname = "";
		this.pword = "";
		this.type = "Sup";
	}

	public Supervisor(String type, int id, String fname, String lname, String pword) {
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.pword = pword;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	
	public String toString() {
		return "StaffID: " + id + "\nName: " + fname + " " + lname + "\nType: Supervisor";
	}

	public static void assignAdvisor(String issueID, String staffID) {
	    String sql = "UPDATE `query_management`.`issue` SET `staff_ID` = '" + staffID + "' WHERE (`issue_ID` = '" + issueID + "');";
	    try {
	        Connection dbConn = DBConnect.getDatabaseConnection();
	        PreparedStatement stmt = dbConn.prepareStatement(sql);
	        
	        int rowsUpdated = stmt.executeUpdate();
	        if (rowsUpdated == 1) {
	            JOptionPane.showMessageDialog(null, "Record updated successfully",
	                    "Update record Status", JOptionPane.INFORMATION_MESSAGE);
	        } else {
	            JOptionPane.showMessageDialog(null, "Failed to update record",
	                    "Update record Status", JOptionPane.ERROR_MESSAGE);
	        }
	    } catch (SQLException ex) {
	        ex.printStackTrace();
	    }
	}
	
	public static Supervisor getStaffInfo(int j) {
		Supervisor staff = new Supervisor();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT * FROM `Query_Management`.`Staff` WHERE `Staff`.`staff_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				staff.setId(rs.getInt(1));
				staff.setFname(rs.getString(2));
				staff.setLname(rs.getString(3));
				staff.setType(rs.getString(4));
				
				System.out.println(staff);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return staff;
	}
	
	public static List<String> getStaffAllInfo() {
		Supervisor staff = new Supervisor();
		List<String> data = new ArrayList<>();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT * FROM `Query_Management`.`Staff`;";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			while (rs.next()) {
				staff.setId(rs.getInt(1));
				staff.setFname(rs.getString(2));
				staff.setLname(rs.getString(3));
				staff.setType(rs.getString(4));
				data.add(staff.getFname() + " " + staff.getLname());
				System.out.println(staff);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
	
	public static Supervisor getStaffInfo(String j) {
		Supervisor staff = new Supervisor();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT * FROM `Query_Management`.`Staff` WHERE `Staff`.`staff_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				staff.setId(rs.getInt(1));
				staff.setFname(rs.getString(2));
				staff.setLname(rs.getString(3));
				staff.setType(rs.getString(4));
				
				System.out.println(staff);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return staff;
	}


	public static void main(String[] args) {
		Supervisor.assignAdvisor("106", "1001");
	}

}
