/**
 * 
 */
package project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author Kyle
 *
 */
public class Advisor{
	private static final Logger Logger = LogManager.getLogger(Login.class);
	
	private String type;
	private int id;
	private String fname;
	private String lname;
	private String pword;
	
	public Advisor() {
		this.id = 0;
		this.fname = "";
		this.lname = "";
		this.pword = "";
		this.type = "Adv";
	}

	public Advisor(String type, int id, String fname, String lname, String pword) {
		this.id = id;
		this.fname = fname;
		this.lname = lname;
		this.pword = pword;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getPword() {
		return pword;
	}

	public void setPword(String pword) {
		this.pword = pword;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String toString() {
		return "StaffID: " + id + "\nName: " + fname + " " + lname + "\nType: Advisor";
	}
	
	public static Issue getMyIssues(Advisor staff) {
		Issue issue = new Issue();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `staff_ID` ='" + staff.getId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				System.out.println(issue);
				return issue;
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
			Logger.error("Test ERROR Message" + ex);
		}
		return null;			
	}
	
	public static Advisor getStaffInfo(int j) {
		Advisor staff = new Advisor();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT * FROM `Query_Management`.`Staff` WHERE `Staff`.`staff_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				staff.setId(rs.getInt(1));
				staff.setFname(rs.getString(2));
				staff.setLname(rs.getString(3));
				staff.setType(rs.getString(4));
								
				System.out.println(staff);
				}
		}catch (Exception e) {
			e.printStackTrace();
			Logger.error("Test ERROR Message" + e);
		}
		return staff;
	}
	
	public static Advisor getStaffInfo(String j) {
		Advisor staff = new Advisor();
		int i = 1;
		try {				 
			Connection con = DBConnect.getDatabaseConnection();
			Statement stmt=con.createStatement();
			String sql = "SELECT * FROM `Query_Management`.`Staff` WHERE `Staff`.`staff_ID`='" + j + "';";	    
			ResultSet rs = stmt.executeQuery(sql);
					
			if (rs.next()) {
				staff.setId(rs.getInt(1));
				staff.setFname(rs.getString(2));
				staff.setLname(rs.getString(3));
				//staff.setType(rs.getString(4));
				
				System.out.println(staff);
				}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return staff;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
