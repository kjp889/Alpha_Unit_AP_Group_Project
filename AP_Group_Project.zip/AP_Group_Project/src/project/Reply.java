package project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Reply {
	private int id;
	private int issueID;
	private String reply;
	private String date;
	private int staffid;
	private int studId;

	public Reply() {
		this.id = 0;
		this.issueID = 0;
		this.reply = "";
	}

	public Reply(int id, int issueID, String reply) {
		this.id = id;
		this.issueID = issueID;
		this.reply = reply;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public int getStaffid() {
		return staffid;
	}

	public void setStaffid(int staffid) {
		this.staffid = staffid;
	}

	public int getIssueID() {
		return issueID;
	}

	public void setIssueID(int issueID) {
		this.issueID = issueID;
	}

	public String getReply() {
		return reply;
	}

	public void setReply(String reply) {
		this.reply = reply;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "ID: " + id + "\nIssueID:" + issueID + "\nStudent ID: " + studId + "\nPrevious Reply: " + reply ;
	}
	
	public static void replyToIssue(Reply reply) {
		String sql = "INSERT INTO `query_management`.`reply` (`replyID`, `issue_ID`, `date_Of_reply`, `reply`) VALUES "
				+ "('" + reply.getId() + "', '" + reply.getIssueID() + "', (CURRENT_TIMESTAMP), '" + reply.getReply() + "');";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			//ResultSet rs = stmt.executeQuery(sql);
			
			if (stmt.executeUpdate(sql) == 1) {
				JOptionPane.showMessageDialog(null, "Record added",
						"Add record Stat", JOptionPane.INFORMATION_MESSAGE);
				
			}else {
				JOptionPane.showMessageDialog(null, "Failed",
						"Add record Stat", JOptionPane.ERROR_MESSAGE);
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
	}
	
	public static Reply getReplysById(int r) {
		Reply repi = new Reply();
		String sql = "SELECT * FROM `query_management`.`reply` WHERE `issue_ID` = '" + r + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				repi.setId(rs.getInt(1));
				repi.setIssueID(rs.getInt(2));
				repi.setDate(rs.getString(3));
				repi.setReply(rs.getString(4));
				System.out.println(repi);
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return repi;			
	}
	
	public static Reply getByRepId(int r) {
		Reply repi = new Reply();
		String sql = "SELECT * FROM `query_management`.`reply` WHERE `replyID` = '" + r + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			if (rs.next()) {
				repi.setId(rs.getInt(1));
				repi.setIssueID(rs.getInt(2));
				repi.setDate(rs.getString(3));
				repi.setReply(rs.getString(4));
				System.out.println(repi);
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return repi;			
	}
	
	public static  ArrayList<Object[]> getReplys(Issue issue) {
		Reply repi = new Reply();
		ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`reply` WHERE `issue_ID` = '" + issue.getIssueId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				repi.setId(rs.getInt(1));
				repi.setIssueID(rs.getInt(2));
				repi.setDate(rs.getString(3));
				repi.setReply(rs.getString(5));
				repi.setStaffid(rs.getInt(4));
				repi.setStudId(rs.getInt(6));
				System.out.println(repi);
				data.add(new Object[]{repi.getId(), repi.getIssueID(), repi.getDate(),
		        		repi.getReply(), repi.getStaffid()});
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return data;			
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Reply rep = new Reply(2,103,"not now");
		Reply.replyToIssue(rep);*/
		
		Issue issue = new Issue();
		
		getReplys(issue);

	}

}
