package project;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Issue {
	private int issueId;
	private int studId;
	private int advisorId;
	private String date;
	private String issue;
	private String type;
	
	public Issue() {
		this.issueId = 100;
		this.studId = 0;
		this.advisorId = 0;
		this.issue = "need money";
		this.date = "";
		this.type = "";
	}

	public Issue(int issueId, int studId, int advisorId, String issue, String date, String type) {
		this.issueId = issueId;
		this.studId = studId;
		this.advisorId = advisorId;
		this.issue = issue;
		this.date = date;
		this.type = type;
	}

	public int getIssueId() {
		return issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}

	public int getStudId() {
		return studId;
	}

	public void setStudId(int studId) {
		this.studId = studId;
	}

	public int getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}

	public String getIssue() {
		return issue;
	}

	public void setIssue(String issue) {
		this.issue = issue;
	}
	
	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "Issue ID: " + issueId + "\nStudent ID: " + studId + "\nAdvisor ID: " + advisorId + "\nDate: " + date
				+ "\nType: " + type;
	}

	public static boolean addIssue(Issue issue) {
		String sql = "INSERT INTO `query_management`.`issue` (`issue_ID`, `stud_ID`, `details`, `date_Of_Issue`, `issue_type`) VALUES ('"
				+ issue.getIssueId() + "', '" + issue.getStudId() + "', '" + issue.getIssue() + "', (CURRENT_TIMESTAMP), '" + issue.getType() + "');";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			//ResultSet rs = stmt.executeQuery(sql);
			
			if (stmt.executeUpdate(sql) == 1) {
				JOptionPane.showMessageDialog(null, "Record added",
						"Add record Stat", JOptionPane.INFORMATION_MESSAGE);
				return true;
			}else {
				JOptionPane.showMessageDialog(null, "Failed",
						"Add record Stat", JOptionPane.ERROR_MESSAGE);
				return false;
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return (Boolean) null;
	}
	
	public static Issue getIssuesFromFile() {
		Issue issue = new Issue();
		String sql = "SELECT * FROM `query_management`.`issue`;";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
			}
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return issue;			
	}
	
	public static Issue getIssuesByID(int id) {
		Issue issue = new Issue();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `issue_ID` = '"+ id +"';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
				return issue;
			}
			
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return issue;			
	}
	
	public static ArrayList<Object[]> getIssuesFromFile(Student stu) {
		Issue issue = new Issue();
		ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `stud_ID` = '"
				+ stu.getStudId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
		        data.add(new Object[]{issue.getIssueId(), issue.getStudId(), issue.getAdvisorId(),
		        		issue.getDate(), issue.getIssue()});
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return data;			
	}
	
	public static ArrayList<Object[]> getIssuesByStaffID(Supervisor staff) {
		Issue issue = new Issue();
		ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `staff_ID` = '"
				+ staff.getId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
		        data.add(new Object[]{issue.getIssueId(), issue.getStudId(), issue.getAdvisorId(),
		        		issue.getDate(), issue.getIssue()});
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return data;			
	}
	
	public static ArrayList<Object[]> getIssuesByStaffID(Advisor staff) {
		Issue issue = new Issue();
		ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `staff_ID` = '"
				+ staff.getId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
		        data.add(new Object[]{issue.getIssueId(), issue.getStudId(), issue.getAdvisorId(),
		        		issue.getDate(), issue.getIssue()});
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return data;			
	}
	
	public static ArrayList<Object[]> getAllIssueFromFile() {
		Issue issue = new Issue();
		ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`issue`;";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);
		        data.add(new Object[]{issue.getIssueId(), issue.getStudId(), issue.getAdvisorId(),
		        		issue.getDate(), issue.getIssue()});
				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return data;			
	}
	
	public static Issue getLastIssueFromFile(Student stu) {
		Issue issue = new Issue();
		//ArrayList<Object[]> data = new ArrayList<>();
		String sql = "SELECT * FROM `query_management`.`issue` WHERE `stud_ID` = '"
				+ stu.getStudId() + "';";
		try {
			Connection dbConn = DBConnect.getDatabaseConnection();
			Statement stmt = dbConn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				issue.setIssueId(rs.getInt(1));
				issue.setIssue(rs.getString(2));
				issue.setDate(rs.getString(3));
				issue.setStudId(rs.getInt(4));
				issue.setAdvisorId(rs.getInt(5));
				issue.setType(rs.getString(6));
				System.out.println(issue);				
			}
		}catch(SQLException ex) {
			ex.printStackTrace();
		}
		return issue;			
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Issue isse = new Issue();
		
		//addIssue(isse);
		getIssuesFromFile();
	}

}
