/*
 * Name: Alpha Unit
Pete Aris ID#1704057
Renardo Bryan ID#1808008
Kyle Parris ID#1804904
Damain Rose ID#2002580
 */


package driver;

import gui.LoginGui;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LoginGui();
	}

}
