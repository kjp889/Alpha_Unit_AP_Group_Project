package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import project.Reply;

public class ReplyFrame extends JFrame{
	
	ReplyFrame(int i){
		//Reply r = new Reply();
		Reply r = Reply.getByRepId(i);
		
		// create components
	    JPanel leftArea = new JPanel(new GridLayout(2, 1));
	    JPanel buttonPan = new JPanel(new GridLayout(1, 2));
	    JPanel rightArea = new JPanel(new GridLayout(2, 1));
	    JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftArea, rightArea);
	    splitPane.setResizeWeight(0.7);
	    
	    // add split pane to frame
	    setContentPane(splitPane);
	   
	    JTextArea text = new JTextArea();
	    JTextArea text2 = new JTextArea();
	    text2.setBounds(20, 350 , 240, 30);
	    text2.setLineWrap(true);
        text2.setWrapStyleWord(true);
	    text.setText("\n\n\n" + r.toString());
	    text.setFont(new Font("Arial Black", Font.PLAIN, 12));
	    text2.setFont(new Font("Arial Black", Font.PLAIN, 12));
	    text.setBackground(new Color(182,146,37));
	    text.setEditable(false);
	    text.setLineWrap(true);
        text.setWrapStyleWord(true);
	    leftArea.add(text);
	    leftArea.setBackground(new Color(182,146,37));
	    rightArea.add(text2);
	    
	    
	    // set window properties
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setSize(500, 450);
	    setLocationRelativeTo(null);
	    setVisible(true);
	    
	    JButton click = new JButton();
	   click = new JButton("Send");
	   click.setBounds(170, 500, 80, 30);
	   click.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Reply re = new Reply();
				//int id = ;
				
				re.setId(r.getId() + 1);
				re.setIssueID(r.getIssueID());
				re.setStaffid(r.getStaffid());
				re.setReply(text2.getText());
				Reply.replyToIssue(re);
				re.setId(r.getId() + 1);
					//boolean flag = Reply.replyToIssue(re);
				
				dispose();
			}
		});
	   JButton click2 = new JButton();
	   click2 = new JButton("Cancel");
	   click2.setBounds(170, 500, 80, 30);
	   click2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {	
				dispose();
			}
		});
	   	buttonPan.add(click);
	   	buttonPan.add(click2);	   	
	    rightArea.add(buttonPan);
	}
}
