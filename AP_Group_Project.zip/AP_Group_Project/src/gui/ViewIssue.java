package gui;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import gui.ListIssue.ButtonEditor;
import gui.ListIssue.ButtonRenderer;
import project.Advisor;
import project.Issue;
import project.Reply;
import project.Student;
import project.Supervisor;

public class ViewIssue {
	static JFrame frame = new JFrame();
	
	public ViewIssue(int id) {
		Issue i = new Issue();
		i = Issue.getIssuesByID(id);
		Student stu = new Student();
		stu.getStudentInfo(i.getStudId());
		Advisor sup = new Advisor();
		sup.getStaffInfo(i.getAdvisorId());
		//Reply rep = new Reply();
		
		ArrayList<Object[]> data = new ArrayList<>(Reply.getReplys(i)); 
		// create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"ReplyID","Date", "Reply"," "}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // only the last column (action) is editable
                return column == 3;
            }
        };

        // add rows to table model
        for (Object[] row : data) {
            model.addRow(new Object[]{row[0], row[2], row[3], "Read"});
        }
        
        

        // create table with custom renderer and editor for the action column
        JTable table = new JTable(model) {
            @Override
            public TableCellRenderer getCellRenderer(int row, int column) {
                if (column == 3) {
                    return new ButtonRenderer();
                }
                return super.getCellRenderer(row, column);
            }

            @Override
            public TableCellEditor getCellEditor(int row, int column) {
                if (column == 3) {
                    return new ButtonEditor(model.getValueAt(row, 0));
                }
                return super.getCellEditor(row, column);
            }
            
        };

        // add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // add scroll pane to frame
       frame.setContentPane(scrollPane);
        
	       
				
		JPanel leftArea = new JPanel(new GridLayout(2, 1));
        JPanel rightArea = new JPanel(new GridLayout(2, 1));
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftArea, rightArea);
        splitPane.setResizeWeight(1.0);
        
        int issID = i.getIssueId();
        JTextArea text = new JTextArea();
        JTextArea text2 = new JTextArea();
        JButton but = new JButton("Reply");
        but.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            		System.out.println(issID);
            	     new ReplyFrame(issID); 
            	     frame.dispose();
            }
        });
        text.setText(i.toString());
        text.setFont(new Font("Arial Black", Font.PLAIN, 12));
        text.setBackground(new Color(182,146,37));
        text.setEditable(false);
        text.setSize(100, 100);
        text2.setText(i.getIssue());
        text2.setFont(new Font("Arial Black", Font.PLAIN, 25));
        text2.setBackground(new Color(182,146,37));
        text2.setEditable(false);
        text2.setSize(100, 100);
        text2.setLineWrap(true);
        text2.setWrapStyleWord(true);
        leftArea.add(text);
        leftArea.add(text2);
        leftArea.setBackground(new Color(182,146,37));
        leftArea.setSize(100, 100);
        
        JInternalFrame inf = new JInternalFrame();
        //inf = replyFrame();
        
        rightArea.add(table);
        rightArea.add(but);
        
        frame.setContentPane(splitPane);
        
        JMenuBar menuBar = new JMenuBar();
        
        JMenuItem back = new JMenuItem("Back");
		back.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame.dispose();
			}
		});
		
		menuBar.add(back);
		        
        // set window properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 450);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setJMenuBar(menuBar);
	}
	
	// custom button renderer for the action column
    static class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }
    

    // custom button editor for the action column
    static class ButtonEditor extends DefaultCellEditor {
        protected JButton button;

        private String label;

        public ButtonEditor(Object object) {
            super(new JTextField());
            setClickCountToStart(1);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	System.out.println(object);
                	     new ReplyFrame((int) object);        	                    
                }
            });
            
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            return button;
        } 
    }
    
   
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
