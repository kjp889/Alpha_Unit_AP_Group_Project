package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import project.Issue;
import project.Reply;
import project.Student;
import project.Supervisor;
public class AssignIssueGui extends JFrame{
		
		public AssignIssueGui() {
			
			JInternalFrame iframe = new JInternalFrame();
			JPanel framePan = new JPanel(new GridLayout(2, 1));
			JPanel txtPan = new JPanel(new GridLayout(1, 2));
		    JPanel buttonPan = new JPanel(new GridLayout(1, 2));
		    JTextArea txt = new JTextArea();
		    JTextArea txt2 = new JTextArea();
		    //JPanel rightArea = new JPanel(new GridLayout(2, 1));
		    txt.setBounds(20, 350 , 240, 30);
		    txt.setLineWrap(true);
	        txt.setWrapStyleWord(true);
	        txt.setText("Enter Issue Id here");
	        txt2.setBounds(20, 350 , 240, 30);
		    txt2.setLineWrap(true);
	        txt2.setWrapStyleWord(true);
	        txt2.setText("Enter Staff Id here");
	        
	        JButton click = new JButton();
	 	   click = new JButton("Submit");
	 	   click.setBounds(170, 500, 80, 30);
	 	   click.addActionListener(new ActionListener() {
	 			public void actionPerformed(ActionEvent arg0) {
	 				Supervisor.assignAdvisor(txt.getText(), txt2.getText());
	 				
	 				dispose();
	 			}
	 		});
	 	   JButton click2 = new JButton();
	 	   click2 = new JButton("Cancel");
	 	   click2.setBounds(170, 500, 80, 30);
	 	   click2.addActionListener(new ActionListener() {
	 			public void actionPerformed(ActionEvent arg0) {
	 				
	 				dispose();
	 			}
	 		});
	 	   	buttonPan.add(click);
	 	   	buttonPan.add(click2);	
	 	   txtPan.add(txt);
	 	  txtPan.add(txt2);
		    framePan.add(txtPan);
		    framePan.add(buttonPan);
		    iframe.add(framePan);
		    iframe.setVisible(true);
		    add(iframe);
		    		    
		 // set window properties
	        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	        setSize(500, 450);
	        setLocationRelativeTo(null);
	        setVisible(true);
	        //setJMenuBar(menuBar);	
		}

		public static void main(String[] args) {
			// TODO Auto-generated method stub

		}

	}


