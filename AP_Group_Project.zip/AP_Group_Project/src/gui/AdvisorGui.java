package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

import project.Advisor;
import project.Issue;

import project.Student;

public class AdvisorGui extends JFrame{
	
JButton click = new JButton();
	
	public AdvisorGui(Advisor adv) {
		ArrayList<Object[]> data = new ArrayList<>(Issue.getIssuesByStaffID(adv)); 
                    
        // create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"Date", "Complaints"});
        
        int i = 0;
        // add rows to table model
        for (Object[] row : data) {
        	i++;
        	if(i<=15) {
        		model.addRow(new Object[]{row[3], row[4]});
        	}
        }
        
        // create table and add to scroll pane
        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        table.getColumnModel().getColumn(1).setPreferredWidth(500); // set preferred width of first column
        table.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        
        // add scroll pane to frame
        setContentPane(scrollPane);
        
             
        // create components
        JPanel leftArea = new JPanel();
        JPanel rightArea = new JPanel();
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftArea, rightArea);
        splitPane.setResizeWeight(0.7);
        
        // add split pane to frame
        setContentPane(splitPane);
        rightArea.add(table);
        JTextArea text = new JTextArea();
        text.setText("\n\n\n" + adv.toString());
        text.setFont(new Font("Arial Black", Font.PLAIN, 12));
        text.setBackground(new Color(182,146,37));
        text.setEditable(false);
        leftArea.add(text);
        leftArea.setBackground(new Color(182,146,37));
        
        JMenuBar menuBar = new JMenuBar();
        
        JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				dispose();
			}
		});

        JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AdvisorGui(adv);
				dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("View Issues");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, adv);
				dispose();
			}
		});
		        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        //menuBar.add(comp);
       // menuBar.add(menu4);
        
        // set window properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setVisible(true);
        setJMenuBar(menuBar);
        
       click = new JButton("Queries/Complaints");
       click.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, adv);
				dispose();
			}
		});
        rightArea.add(click);
    }
		
	private void button() {
		click.setBounds(170, 500, 80, 30);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
