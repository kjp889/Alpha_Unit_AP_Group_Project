package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import project.Login;

public class LoginGui extends JFrame {
	private static final long serialVersionUID = 1L;
	private JLabel usernameLabel;
	private JLabel passwordLabel;
	private JTextField usernameTextField;
	private JPasswordField passwordField;
	private JPanel panel1;
	private JPanel panel2;
	private JLabel textLabel;
	private JButton login;
	
	public LoginGui() {
		usernameLabel = new JLabel("USERNAME");
		passwordLabel = new JLabel("PASSWORD");
		textLabel = new JLabel("Login");
		usernameTextField = new JTextField(20);
		passwordField = new JPasswordField(20);
		panel1 = new JPanel();
	    panel2 = new JPanel();
	    setSize(1000,650);
		setVisible(true);
		setBackground(Color.cyan);
		setResizable(true);
		setLayout(null);
		setVisible(true);
		setTitle("Utech");
		login = new JButton("Login");
		login.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Login.login(usernameTextField.getText(), passwordField.getText());
				dispose();
			}
		});
		
		Panel();
	}
	
	private void Panel()  {
		// TOD Auto-generated method stub
		button();
		Label();
		Textbox();
		panel1.setBounds(0, 0, 550, 750);
		panel1.setBackground(new Color(5,14,35));
		panel2.setBounds(550, 0, 450, 750);
		panel2.setBackground(new Color(182,146,37));
		panel2.setLayout(null);
		panel2.add(usernameLabel);
		panel2.add(passwordLabel);
		panel2.add(usernameTextField);
		panel2.add(passwordField);
		panel2.add(textLabel);
		panel2.add(login);
		add(panel1);
		add(panel2);
	
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		setLocationRelativeTo(null);
	}

	private void button() {
		login.setBounds(170, 500, 80, 30);
	}
	
	private void Label() {
		usernameLabel.setFont(new Font("Calibri", Font.BOLD, 14));
		usernameLabel.setBounds(20, 300 , 100, 50);
		passwordLabel.setBounds(20, 400 , 100,50);
		textLabel.setBounds(100, 200, 350, 30);
		textLabel.setFont(new Font("Calibri", Font.BOLD, 35));
		passwordLabel.setFont(new Font("Calibri", Font.BOLD, 14));
		usernameLabel.setForeground(Color.BLACK);
		textLabel.setForeground(Color.BLACK);
		passwordLabel.setForeground(Color.BLACK);
	}

	private void Textbox() {
		usernameTextField.setBounds(20, 350 , 240, 30);
		passwordField.setBounds(20, 450 , 240, 30);
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new LoginGui();
	}

}
