package gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import project.Issue;
import project.Reply;
import project.Student;

public class MakeQueryGUI extends JFrame{
	
	public MakeQueryGUI(Student stu, String type) {
		final Issue iss = Issue.getLastIssueFromFile(stu);
		
		JInternalFrame iframe = new JInternalFrame();
		JPanel framePan = new JPanel(new GridLayout(2, 1));
	    JPanel buttonPan = new JPanel(new GridLayout(1, 2));
	    JTextArea txt = new JTextArea();
	    //JPanel rightArea = new JPanel(new GridLayout(2, 1));
	    txt.setBounds(20, 350 , 240, 30);
	    txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        
        JButton click = new JButton();
 	   click = new JButton("Submit");
 	   click.setBounds(170, 500, 80, 30);
 	   click.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent arg0) {
 				Issue i = new Issue();
 				i.setIssueId(iss.getIssueId() + 1);
 				i.setIssue(txt.getText());
 				i.setStudId(stu.getStudId());
 				i.setType(type);
 				boolean flag = Issue.addIssue(i);
 				while(flag == false) {
 					i.setIssueId(iss.getIssueId() + 1);
 				}
 				new StudentDashboard(stu);
 				dispose();
 			}
 		});
 	   JButton click2 = new JButton();
 	   click2 = new JButton("Cancel");
 	   click2.setBounds(170, 500, 80, 30);
 	   click2.addActionListener(new ActionListener() {
 			public void actionPerformed(ActionEvent arg0) {
 				new StudentDashboard(stu);
 				dispose();
 			}
 		});
 	   	buttonPan.add(click);
 	   	buttonPan.add(click2);	   
	    framePan.add(txt);
	    framePan.add(buttonPan);
	    iframe.add(framePan);
	    iframe.setVisible(true);
	    add(iframe);
	    
	    JMenuBar menuBar = new JMenuBar();
        
        JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				dispose();
			}
		});

        JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new StudentDashboard(stu);
				dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("Make Query");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new MakeQueryGUI(stu, "Query");
				dispose();
			}
		});
		JMenuItem comp = new JMenuItem("Make Complaint");
        comp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new MakeQueryGUI(stu, "Complaint");
				dispose();
			}
		});
        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        menuBar.add(comp);
       // menuBar.add(menu4);
	    
	 // set window properties
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 650);
        setLocationRelativeTo(null);
        setVisible(true);
        setJMenuBar(menuBar);	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
