package gui;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;

import project.Advisor;
import project.Issue;
import project.Student;
import project.Supervisor;


public class ListIssue{
	static JFrame frame = new JFrame();
	public ListIssue(ArrayList<Object[]> data, Student stu) {
       
		// create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"Issue ID", "Date", "Complaints", " "}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // only the last column (action) is editable
                return column == 3;
            }
        };

        // add rows to table model
        for (Object[] row : data) {
            model.addRow(new Object[]{row[0], row[3], row[4], "View"});
        }
        
        

        // create table with custom renderer and editor for the action column
        JTable table = new JTable(model) {
            @Override
            public TableCellRenderer getCellRenderer(int row, int column) {
                if (column == 3) {
                    return new ButtonRenderer();
                }
                return super.getCellRenderer(row, column);
            }

            @Override
            public TableCellEditor getCellEditor(int row, int column) {
                if (column == 3) {
                    return new ButtonEditor(model.getValueAt(row, 0));
                }
                return super.getCellEditor(row, column);
            }
            
        };

        // add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // add scroll pane to frame
       frame.setContentPane(scrollPane);
        
       JMenuBar menuBar = new JMenuBar();
        
        JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				frame.dispose();
			}
		});

        JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new StudentDashboard(stu);
				frame.dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("Make Query");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new MakeQueryGUI(stu, "Query");
				frame.dispose();
			}
		});
		JMenuItem comp = new JMenuItem("Make Complaint");
        comp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new MakeQueryGUI(stu, "Complaint");
				frame.dispose();
			}
		});
        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        menuBar.add(comp);
       // menuBar.add(menu4);
        

        // set window properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 650);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setJMenuBar(menuBar);
    }
	
	public ListIssue(Supervisor staff) {
		ArrayList<Object[]> data = new ArrayList<>(Issue.getAllIssueFromFile());
	       
		// create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"Issue ID", "Date", "Complaints", " "}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // only the last column (action) is editable
                return column == 3;
            }
        };

        // add rows to table model
        for (Object[] row : data) {
            model.addRow(new Object[]{row[0], row[3], row[4], "View"});
        }
        
        

        // create table with custom renderer and editor for the action column
        JTable table = new JTable(model) {
            @Override
            public TableCellRenderer getCellRenderer(int row, int column) {
                if (column == 3) {
                    return new ButtonRenderer();
                }
                return super.getCellRenderer(row, column);
            }

            @Override
            public TableCellEditor getCellEditor(int row, int column) {
                if (column == 3) {
                    return new ButtonEditor(model.getValueAt(row, 0));
                }
                return super.getCellEditor(row, column);
            }
            
        };

        // add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // add scroll pane to frame
       frame.setContentPane(scrollPane);
        
       JMenuBar menuBar = new JMenuBar();
        
       JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				frame.dispose();
			}
		});

       JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new SupervisorGui(staff);
				frame.dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("View Issues");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, staff);
				frame.dispose();
			}
		});
		
		JMenuItem assign = new JMenuItem("Assign Advisor");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(staff);
				frame.dispose();
			}
		});
		
        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        menuBar.add(assign);
       // menuBar.add(menu4);
        

        // set window properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 650);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setJMenuBar(menuBar);
    }
	
	public ListIssue(ArrayList<Object[]> data, Supervisor staff) {
	       
		// create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"Issue ID", "Date", "Complaints", " "}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // only the last column (action) is editable
                return column == 3;
            }
        };

        // add rows to table model
        for (Object[] row : data) {
            model.addRow(new Object[]{row[0], row[3], row[4], "View"});
        }
        
        

        // create table with custom renderer and editor for the action column
        JTable table = new JTable(model) {
            @Override
            public TableCellRenderer getCellRenderer(int row, int column) {
                if (column == 3) {
                    return new ButtonRenderer();
                }
                return super.getCellRenderer(row, column);
            }

            @Override
            public TableCellEditor getCellEditor(int row, int column) {
                if (column == 3) {
                    return new ButtonEditor(model.getValueAt(row, 0));
                }
                return super.getCellEditor(row, column);
            }
            
        };

        // add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // add scroll pane to frame
       frame.setContentPane(scrollPane);
        
       JMenuBar menuBar = new JMenuBar();
        
       JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				frame.dispose();
			}
		});

       JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new SupervisorGui(staff);
				frame.dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("View Issues");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, staff);
				frame.dispose();
			}
		});
		
		JMenuItem assign = new JMenuItem("Assign Advisor");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, staff);
				frame.dispose();
			}
		});
		
        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        menuBar.add(assign);
       // menuBar.add(menu4);
        

        // set window properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 650);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setJMenuBar(menuBar);
    }
	
	public ListIssue(ArrayList<Object[]> data, Advisor staff) {
	       
		// create table model with only the first name and last name columns
        DefaultTableModel model = new DefaultTableModel(new Object[][]{}, new String[]{"Issue ID", "Date", "Complaints", " "}) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // only the last column (action) is editable
                return column == 3;
            }
        };

        // add rows to table model
        for (Object[] row : data) {
            model.addRow(new Object[]{row[0], row[3], row[4], "View"});
        }
        
        

        // create table with custom renderer and editor for the action column
        JTable table = new JTable(model) {
            @Override
            public TableCellRenderer getCellRenderer(int row, int column) {
                if (column == 3) {
                    return new ButtonRenderer();
                }
                return super.getCellRenderer(row, column);
            }

            @Override
            public TableCellEditor getCellEditor(int row, int column) {
                if (column == 3) {
                    return new ButtonEditor(model.getValueAt(row, 0));
                }
                return super.getCellEditor(row, column);
            }
            
        };

        // add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(table);

        // add scroll pane to frame
       frame.setContentPane(scrollPane);
        
       JMenuBar menuBar = new JMenuBar();
        
        JMenuItem logout = new JMenuItem("Log Out");
		logout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new LoginGui();
				frame.dispose();
			}
		});

        JMenuItem home = new JMenuItem("Home");
		home.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new AdvisorGui((Advisor) staff);
				frame.dispose();
			}
		});
		
		JMenuItem query = new JMenuItem("View Issues");
		query.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				new ListIssue(data, staff);
				frame.dispose();
			}
		});
		
        
        menuBar.add(logout);
        menuBar.add(home);
        menuBar.add(query);
        //menuBar.add(comp);
       // menuBar.add(menu4);
        

        // set window properties
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(1000, 650);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        frame.setJMenuBar(menuBar);
    }


    // custom button renderer for the action column
    static class ButtonRenderer extends JButton implements TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
        }

        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            setText((value == null) ? "" : value.toString());
            return this;
        }
    }

    // custom button editor for the action column
    static class ButtonEditor extends DefaultCellEditor {
        protected JButton button;

        private String label;

        public ButtonEditor(Object object) {
            super(new JTextField());
            setClickCountToStart(1);
            button = new JButton();
            button.setOpaque(true);
            button.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                	  System.out.println("Money");              	
                	new ViewIssue((int) object);
                    
                }
            });
            
        }

        public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
            label = (value == null) ? "" : value.toString();
            button.setText(label);
            return button;
        } 
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
